/**
 * @schema TopBar
 * @purpose Apple-style top bar: glass effect, search, actions, user
 */
import { useAuth } from "@/lib/auth";
import { Search, Bell, HelpCircle } from "lucide-react";

interface TopBarProps {
  className?: string;
}

export function TopBar({ className = "" }: TopBarProps) {
  const { data: user } = useAuth();

  return (
    <header
      className={`h-14 sticky top-0 z-10 flex items-center justify-between gap-4 px-6 md:px-10 border-b border-[var(--color-border)] bg-white/72 backdrop-blur-xl ${className}`}
    >
      {/* Search */}
      <div className="flex-1 max-w-md">
        <div className="relative">
          <Search
            size={14}
            strokeWidth={2}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-text-tertiary)] pointer-events-none"
          />
          <input
            type="text"
            placeholder="Suchen…"
            className="w-full h-9 rounded-[8px] border border-transparent bg-[var(--color-gray-50)] pl-9 pr-3 text-[13px] text-[var(--color-text-primary)] placeholder:text-[var(--color-text-tertiary)] outline-none transition-all hover:bg-[var(--color-gray-100)] focus:bg-white focus:border-[var(--color-border-strong)] focus:shadow-[var(--shadow-focus)]"
          />
        </div>
      </div>

      {/* Right side */}
      <div className="flex items-center gap-1">
        <button
          type="button"
          aria-label="Benachrichtigungen"
          className="relative h-9 w-9 inline-flex items-center justify-center rounded-full text-[var(--color-text-secondary)] hover:bg-[var(--color-gray-50)] transition-colors"
        >
          <Bell size={16} strokeWidth={1.75} />
          <span className="absolute top-2 right-2 w-1.5 h-1.5 bg-[var(--color-red-500)] rounded-full" />
        </button>

        <button
          type="button"
          aria-label="Hilfe"
          className="h-9 w-9 inline-flex items-center justify-center rounded-full text-[var(--color-text-secondary)] hover:bg-[var(--color-gray-50)] transition-colors"
        >
          <HelpCircle size={16} strokeWidth={1.75} />
        </button>

        <div className="h-8 w-8 ml-1.5 rounded-full bg-gradient-to-br from-[var(--color-blue-100)] to-[var(--color-blue-200)] flex items-center justify-center text-[12px] font-semibold text-[var(--color-blue-700)] cursor-pointer ring-2 ring-white">
          {user?.email?.charAt(0).toUpperCase() || "?"}
        </div>
      </div>
    </header>
  );
}
