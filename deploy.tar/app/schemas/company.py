"""Schemas für /api/company + /api/auth/profile."""
from __future__ import annotations

from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field


class CompanyRead(BaseModel):
    """Read-Modell: alle Felder der Company, die im Settings-Hub angezeigt werden."""
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    first_name: str = ""
    last_name: str = ""
    business_type: str = ""
    is_small_business: bool = False
    street: str = ""
    postal_code: str = ""
    city: str = ""
    country: str = "Deutschland"
    email: str = ""
    phone: str = ""
    iban: str = ""
    bic: str = ""
    bank_name: str = ""
    tax_id: str = ""
    vat_id: str = ""


class CompanyUpdate(BaseModel):
    """Update-Patch: alle Felder optional, nur erlaubte Felder werden an update_company weitergegeben."""
    name: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    business_type: str | None = None
    is_small_business: bool | None = None
    street: str | None = None
    postal_code: str | None = None
    city: str | None = None
    country: str | None = None
    email: str | None = None
    phone: str | None = None
    iban: str | None = None
    bic: str | None = None
    bank_name: str | None = None
    tax_id: str | None = None
    vat_id: str | None = None

    def patch_dict(self) -> dict:
        """Nicht-None-Felder als Patch (drop None)."""
        return {k: v for k, v in self.model_dump().items() if v is not None}


class UserProfileRead(BaseModel):
    """Read-Modell: User-Stammdaten für /settings/account."""
    model_config = ConfigDict(from_attributes=True)

    id: int
    email: str
    first_name: str = ""
    last_name: str = ""
    phone: str = ""
    is_active: bool = True


class UserProfileUpdate(BaseModel):
    first_name: str | None = None
    last_name: str | None = None
    phone: str | None = None
    email: Annotated[str, Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")] | None = None

    def patch_dict(self) -> dict:
        return {k: v for k, v in self.model_dump().items() if v is not None}
