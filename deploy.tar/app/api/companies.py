# =========================
# APP/API/COMPANIES.PY
# =========================
"""
Company API: /api/company (GET, PUT)

Endpunkte für die React-Settings-Sub-Pages:
- GET /api/company          — Aktuelle Company (für /settings/company, /settings/tax-banking)
- PUT /api/company          — Patch (nur erlaubte Felder, via services.companies.update_company)
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status

from dependencies import get_current_company, require_session_auth
from schemas.company import CompanyRead, CompanyUpdate
from services.companies import update_company


router = APIRouter(prefix="/api/company", tags=["company"])


@router.get("", response_model=CompanyRead)
def get_company(
    company=Depends(get_current_company),
    _user_id: int = Depends(require_session_auth),
) -> CompanyRead:
    """Aktuelle Company-Daten."""
    return CompanyRead.model_validate(company)


@router.put("", response_model=CompanyRead)
def update_current_company(
    payload: CompanyUpdate,
    company=Depends(get_current_company),
    _user_id: int = Depends(require_session_auth),
) -> CompanyRead:
    """Patch (nur erlaubte Felder) auf die aktuelle Company."""
    try:
        updated = update_company(
            user_id=int(_user_id),
            company_id=int(company.id),
            patch=payload.patch_dict(),
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)) from e
    return CompanyRead.model_validate(updated)
