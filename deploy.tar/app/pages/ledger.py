from __future__ import annotations
from ._shared import *
from ._shared import _parse_iso_date
from styles import STYLE_TEXT_MUTED
from ui_components import ff_card, ff_icon_button

# Auto generated page renderer

def render_ledger(session, comp: Company) -> None:
    ui.label("Finanzen").classes(C_PAGE_TITLE + " mb-4")

    def parse_date(value: str | None):
        return _parse_iso_date(value)

    customer_name = func.coalesce(
        func.nullif(Customer.name, ""),
        func.trim(func.coalesce(Customer.vorname, "") + literal(" ") + func.coalesce(Customer.nachname, "")),
    )

    invoice_query = (
        select(
            Invoice.id.label("id"),
            Invoice.date.label("date"),
            Invoice.total_brutto.label("amount"),
            literal("INCOME").label("type"),
            case(
                (Invoice.status == InvoiceStatus.DRAFT, "Draft"),
                (Invoice.status == InvoiceStatus.OPEN, "Open"),
                (Invoice.status == InvoiceStatus.SENT, "Sent"),
                (Invoice.status == InvoiceStatus.PAID, "Paid"),
                (Invoice.status == InvoiceStatus.FINALIZED, "Open"),
                (Invoice.status == InvoiceStatus.CANCELLED, "Cancelled"),
                else_="Overdue",
            ).label("status"),
            func.coalesce(customer_name, literal("?")).label("party"),
            Invoice.title.label("description"),
            Invoice.status.label("invoice_status"),
            Invoice.id.label("invoice_id"),
            literal(None).label("expense_id"),
        )
        .select_from(Invoice)
        .outerjoin(Customer, Invoice.customer_id == Customer.id)
        .where(Customer.company_id == comp.id)
    )

    expense_query = (
        select(
            Expense.id.label("id"),
            Expense.date.label("date"),
            Expense.amount.label("amount"),
            literal("EXPENSE").label("type"),
            literal("Paid").label("status"),
            func.coalesce(Expense.source, Expense.category, Expense.description, literal("-")).label("party"),
            Expense.description.label("description"),
            literal(None).label("invoice_status"),
            literal(None).label("invoice_id"),
            Expense.id.label("expense_id"),
        )
        .where(Expense.company_id == comp.id)
    )

    rows = session.exec(union_all(invoice_query, expense_query)).all()
    items = []
    for row in rows:
        data = row._mapping if hasattr(row, "_mapping") else row
        items.append(
            {
                "id": data["id"],
                "date": data["date"],
                "amount": float(data["amount"] or 0),
                "type": data["type"],
                "status": data["status"],
                "party": data["party"],
                "description": data["description"] or "",
                "invoice_id": data["invoice_id"],
                "expense_id": data["expense_id"],
                "sort_date": parse_date(data["date"]),
            }
        )
    items.sort(key=lambda x: x["sort_date"], reverse=True)

    initial_search = app.storage.user.pop("ledger_search_query", "")
    state = {"type": "ALL", "status": "ALL", "date_from": "", "date_to": "", "search": initial_search}

    def apply_filters(data):
        filtered = []
        for it in data:
            if state["type"] != "ALL" and it["type"] != state["type"]:
                continue
            if state["status"] != "ALL" and it["status"] != state["status"]:
                continue
            if state["date_from"] and it["sort_date"] < parse_date(state["date_from"]):
                continue
            if state["date_to"] and it["sort_date"] > parse_date(state["date_to"]):
                continue
            if state["search"]:
                hay = f"{it['party']} {it.get('description','')}".lower()
                if state["search"].lower() not in hay:
                    continue
            filtered.append(it)
        return filtered

    with ff_card(pad="p-4", classes="mb-4 sticky top-0 z-30"):
        with ui.row().classes("gap-4 w-full items-end flex-wrap sm:flex-nowrap"):
            ui.select({"ALL": "Alle", "INCOME": "Income", "EXPENSE": "Expense"}, label="Typ", value=state["type"],
                      on_change=lambda e: (state.__setitem__("type", e.value or "ALL"), render_list.refresh())).props("outlined dense").classes(C_INPUT + " sm:w-auto")
            ui.select({"ALL": "Alle", "Draft": "Draft", "Open": "Open", "Sent": "Sent", "Paid": "Paid", "Cancelled": "Cancelled"},
                      label="Status", value=state["status"],
                      on_change=lambda e: (state.__setitem__("status", e.value or "ALL"), render_list.refresh())).props("outlined dense").classes(C_INPUT + " sm:w-auto")
            ui.input("Von", on_change=lambda e: (state.__setitem__("date_from", e.value or ""), render_list.refresh())).props("outlined dense type=date").classes(C_INPUT + " sm:w-auto")
            ui.input("Bis", on_change=lambda e: (state.__setitem__("date_to", e.value or ""), render_list.refresh())).props("outlined dense type=date").classes(C_INPUT + " sm:w-auto")
            ui.input("Suche", placeholder="Party oder Beschreibung",
                     on_change=lambda e: (state.__setitem__("search", e.value or ""), render_list.refresh())).props("outlined dense").classes(C_INPUT + " w-full sm:w-56 ff-ledger-search")

    @ui.refreshable
    def render_list():
        data = apply_filters(items)
        if len(data) == 0:
            with ff_card(pad="p-4"):
                with ui.row().classes("w-full justify-center"):
                    ui.label("Keine Ergebnisse gefunden").classes(STYLE_TEXT_MUTED)
            return

        with ff_card(pad="p-0", classes="overflow-hidden"):
            with ui.element("div").classes(C_TABLE_HEADER + " hidden sm:grid sm:grid-cols-[110px_110px_110px_1fr_120px_120px] items-center"):
                ui.label("Datum").classes("font-semibold")
                ui.label("Typ").classes("font-semibold")
                ui.label("Status").classes("font-semibold")
                ui.label("Kunde/Lieferant").classes("font-semibold")
                ui.label("Betrag").classes("font-semibold text-right")
                ui.label("").classes("font-semibold text-right")

            for it in data:
                with ui.element("div").classes(
                    C_TABLE_ROW
                    + " group grid grid-cols-1 sm:grid-cols-[110px_110px_110px_1fr_120px_120px] gap-2 sm:gap-0 items-start sm:items-center"
                    + " border border-slate-200 rounded-lg p-3 sm:p-2 sm:border-0 sm:rounded-none hover:bg-slate-50 transition-colors"
                ):
                    with ui.column().classes("gap-1"):
                        ui.label("Datum").classes("sm:hidden text-xs uppercase text-slate-400")
                        ui.label(it["date"]).classes("text-xs font-mono")

                    with ui.column().classes("gap-1"):
                        ui.label("Typ").classes("sm:hidden text-xs uppercase text-slate-400")
                        badge_class = C_BADGE_YELLOW if it["type"] == "INCOME" else C_BADGE_GRAY
                        ui.label("Income" if it["type"] == "INCOME" else "Expense").classes(badge_class + " w-auto sm:w-20")

                    with ui.column().classes("gap-1"):
                        ui.label("Status").classes("sm:hidden text-xs uppercase text-slate-400")
                        ui.label(it["status"]).classes("text-xs")

                    with ui.column().classes("gap-1"):
                        ui.label("Kunde/Lieferant").classes("sm:hidden text-xs uppercase text-slate-400")
                        ui.label(it["party"]).classes("text-sm")
                        if it.get("description"):
                            ui.label(it["description"]).classes("text-xs text-slate-500")

                    with ui.column().classes("gap-1 sm:items-end"):
                        ui.label("Betrag").classes("sm:hidden text-xs uppercase text-slate-400")
                        amount_label = f"{it['amount']:,.2f} €" if it["type"] == "INCOME" else f"-{it['amount']:,.2f} €"
                        amount_class = (
                            f"text-right text-sm font-mono {C_NUMERIC} "
                            + ("text-emerald-600" if it["type"] == "INCOME" else "text-rose-600")
                        )
                        ui.label(amount_label).classes(amount_class)

                    with ui.row().classes("justify-end gap-1 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition"):
                        if it["invoice_id"]:
                            ff_icon_button(
                                icon="open_in_new",
                                on_click=lambda _, iid=it["invoice_id"]: _open_invoice_detail(int(iid)),
                            )
                        else:
                            ui.label("-").classes("text-xs text-slate-400")

    render_list()
