from __future__ import annotations
import os
import tempfile

from ._shared import *
from styles import STYLE_TEXT_MUTED
from ui_components import ff_btn_secondary, ff_card

# Auto generated page renderer

def render_exports(session, comp: Company) -> None:
    ui.label("Exporte").classes(C_PAGE_TITLE + " mb-4")

    def run_export(action, label: str):
        ui.notify("Wird vorbereitet…")
        try:
            with get_session() as s:
                result = action(s, comp.id)
            if isinstance(result, (bytes, bytearray)):
                suffix = ".zip" if bytes(result[:4]) == b"PK\x03\x04" else ".csv"
                temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=suffix, prefix="export_")
                temp_path = temp_file.name
                temp_file.write(result)
                temp_file.close()
                ui.download(temp_path)
                ui.notify(f"{label} bereit", color="grey")
                return
            if result and os.path.exists(result):
                ui.download(result)
                ui.notify(f"{label} bereit", color="grey")
                return
            ui.notify("Export fehlgeschlagen", color="orange")
        except Exception as e:
            ui.notify(f"Fehler: {e}", color="orange")

    def export_card(title: str, description: str, action):
        with ff_card(pad="p-5", classes="w-full", hover=True):
            ui.label(title).classes(C_SECTION_TITLE)
            ui.label(description).classes(f"{STYLE_TEXT_MUTED} mb-2")
            ff_btn_secondary("Download", icon="download", on_click=action)

    with ui.element("div").classes("w-full grid grid-cols-1 sm:grid-cols-2 gap-4"):
        export_card("Dokumente ZIP", "Alle Dokumente als ZIP-Datei", lambda: run_export(export_documents_zip, "Dokumente ZIP"))
        export_card("Rechnungen CSV", "Alle Rechnungen als CSV-Datei", lambda: run_export(export_invoices_csv, "Rechnungen CSV"))
        export_card("Positionen CSV", "Alle Rechnungspositionen als CSV-Datei", lambda: run_export(export_invoice_items_csv, "Positionen CSV"))
        export_card("Kunden CSV", "Alle Kunden als CSV-Datei", lambda: run_export(export_customers_csv, "Kunden CSV"))
        export_card("DB-Backup", "SQLite Datenbank sichern", lambda: run_export(export_database_backup, "DB-Backup"))
