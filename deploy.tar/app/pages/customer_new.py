from __future__ import annotations
from ._shared import *
from ui_components import ff_btn_primary, ff_input

# Auto generated page renderer


def render_customer_new(session, comp: Company) -> None:
    ui.label("Neuer Kunde").classes(C_PAGE_TITLE)
    if app.storage.user.get("return_page") == "invoice_create":
        ui.label("Dieser Kunde wird nach dem Speichern in der Rechnungserstellung vorausgewählt.").classes(
            STYLE_TEXT_MUTED + " mb-2"
        )

    with settings_two_column_layout(max_width_class="max-w-4xl"):
        contact_fields = customer_contact_card()
        address_fields = customer_address_card(country_value=comp.country or "DE")
        with settings_card("Rechnungsempfänger"):
            same_recipient_checkbox = ui.checkbox(
                "Rechnungsempfänger = Kontaktadresse",
                value=True,
            ).classes("mb-2")
            with settings_grid():
                recipient_name = ff_input("Rechnungsempfänger", value="")
                recipient_street = ff_input("Rechnungsstraße", value="")
                recipient_plz = ff_input("Rechnungs-PLZ", value="")
                recipient_city = ff_input("Rechnungs-Ort", value="")

    name = contact_fields["name"]
    prefill_name = str(app.storage.user.pop("new_customer_prefill_name", "") or "").strip()
    if prefill_name:
        name.value = prefill_name
    first = contact_fields["first"]
    last = contact_fields["last"]
    email = contact_fields["email"]
    short_code = contact_fields["short_code"]
    street = address_fields["street"]
    plz = address_fields["plz"]
    city = address_fields["city"]
    country = address_fields["country"]

    def _contact_display_name() -> str:
        name_value = (name.value or "").strip()
        if name_value:
            return name_value
        return f"{first.value or ''} {last.value or ''}".strip()

    def _sync_recipient_with_contact() -> None:
        recipient_name.value = _contact_display_name()
        recipient_street.value = street.value or ""
        recipient_plz.value = plz.value or ""
        recipient_city.value = city.value or ""

    def _maybe_sync_recipient() -> None:
        if same_recipient_checkbox.value:
            _sync_recipient_with_contact()

    same_recipient_checkbox.on("update:model-value", lambda _: _maybe_sync_recipient())
    _maybe_sync_recipient()

    def save() -> None:
        with get_session() as s:
            c = insert_customer(
                s,
                comp,
                name=name.value or "",
                vorname=first.value or "",
                nachname=last.value or "",
                email=email.value or "",
                short_code=short_code.value or "",
                strasse=street.value or "",
                plz=plz.value or "",
                ort=city.value or "",
                country=country.value or "",
                recipient_name=recipient_name.value or "",
                recipient_street=recipient_street.value or "",
                recipient_postal_code=recipient_plz.value or "",
                recipient_city=recipient_city.value or "",
            )
            new_customer_id = int(c.id) if c.id is not None else None

        return_page = app.storage.user.get("return_page")
        if return_page == "invoice_create" and new_customer_id is not None:
            return_invoice_draft_id = app.storage.user.get("return_invoice_draft_id")
            if return_invoice_draft_id is not None:
                app.storage.user["invoice_draft_id"] = return_invoice_draft_id
            app.storage.user.pop("return_page", None)
            app.storage.user.pop("return_invoice_draft_id", None)
            app.storage.user["new_customer_id"] = new_customer_id
            ui.notify("Kunde gespeichert – zurück zur Rechnung.", type="positive")
            go_app_page("invoice_create")
            return

        go_app_page("customers")

    ff_btn_primary("Speichern", on_click=save)
