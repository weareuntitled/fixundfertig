"""Storage helpers."""
